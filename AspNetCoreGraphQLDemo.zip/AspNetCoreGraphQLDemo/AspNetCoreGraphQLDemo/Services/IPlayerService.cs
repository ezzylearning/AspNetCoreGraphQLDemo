﻿using AspNetCoreGraphQLDemo.Models;

namespace AspNetCoreGraphQLDemo.Services
{
    public interface IPlayerService
    {
        Task<IEnumerable<Player>> GetPlayersAsync();
    }
}