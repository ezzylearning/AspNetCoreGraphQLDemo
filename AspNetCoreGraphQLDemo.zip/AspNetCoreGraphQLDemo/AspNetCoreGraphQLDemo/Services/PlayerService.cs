﻿using AspNetCoreGraphQLDemo.Data;
using AspNetCoreGraphQLDemo.Models;
using Microsoft.EntityFrameworkCore;

namespace AspNetCoreGraphQLDemo.Services
{
    public class PlayerService : IPlayerService
    {
        private readonly SportsDbContext _context;

        public PlayerService(SportsDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Player>> GetPlayersAsync()
        {
            return await _context.Players
                .Include(x => x.Position)
                .ToListAsync();
        }

        public async Task<Player> GetPlayerAsync(int id)
        {
            return await _context.Players
                .Include(x => x.Position)
                .Where(x => x.Id == id)
                .SingleAsync();
        } 
    }
}
