﻿using AspNetCoreGraphQLDemo.Models;
using AspNetCoreGraphQLDemo.Services;

namespace AspNetCoreGraphQLDemo.Api
{
    public class Query
    {
        public async Task<IEnumerable<Player>> GetPlayersAsync([Service] IPlayerService playerService)
        {
            return await playerService.GetPlayersAsync();
        }
    }
}
